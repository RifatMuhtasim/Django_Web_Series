from story.models import StoryPost
from django.contrib import admin
from .models import StoryPost
# Register your models here.

admin.site.register(StoryPost)